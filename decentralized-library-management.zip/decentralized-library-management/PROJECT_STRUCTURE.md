# Project Structure Documentation

## Overview

The Library Management DApp is organized into several key components:

1. **Smart Contracts** - The blockchain logic
2. **Frontend** - The React user interface
3. **Scripts** - Utility and deployment scripts
4. **Tests** - Contract tests

## Directory Structure

